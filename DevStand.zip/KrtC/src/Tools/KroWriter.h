#ifndef KRT_KRO_WRITER_H
#define KRT_KRO_WRITER_H

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>


#define KRO_MAGIC    0x4523454Fu
#define KRO_VERSION  1

#define KRO_ARCH_X86_64  0x8664
#define KRO_ARCH_ARM64   0xAA64

#define KRO_SEC_COUNT    4  // Actual section count (text, data, rodata, bss)

// Section indices for ArkLink compatibility
// ArkLink uses 0 for undefined/external symbols, 1+ for actual sections
typedef enum {
    KRO_SEC_UNDEF  = 0,  // Undefined/external symbol (ArkLink convention)
    KRO_SEC_TEXT   = 1,  // .text section
    KRO_SEC_DATA   = 2,  // .data section
    KRO_SEC_RODATA = 3,  // .rdata section
    KRO_SEC_BSS    = 4,  // .bss section
} KROSectionIndex;

#define KRO_SECF_READ    0x01
#define KRO_SECF_WRITE   0x02
#define KRO_SECF_EXEC    0x04
#define KRO_SECF_BSS     0x08

#define KRO_SYM_NOTYPE   0
#define KRO_SYM_FUNC     1
#define KRO_SYM_OBJECT   2

#define KRO_BIND_LOCAL   0
#define KRO_BIND_GLOBAL  1
#define KRO_BIND_WEAK    2

// ArkLink compatible relocation types
#define KRO_RELOC_ABS64  1   // 64-bit absolute address
#define KRO_RELOC_PC32   3   // 32-bit PC-relative address (matches ARK_RELOC_PC32)

#define KRO_FLAG_IMPORT  0x8000

#pragma pack(push, 1)

typedef struct {
    uint32_t magic;
    uint16_t version;
    uint16_t flags;
    uint16_t arch;
    uint16_t reserved;
    uint32_t sec_count;
    uint32_t sym_count;
    uint64_t strtab_size;
    uint64_t entry_point;
} KROHeader;


typedef struct {
    char     name[8];         
    uint8_t  align_log2;      
    uint8_t  flags;           
    uint16_t reserved;        

    uint32_t file_offset;     
    uint32_t file_size;       
    uint32_t mem_size;        
    uint32_t reloc_count;     
    uint32_t reloc_offset;    
} KROSection;


typedef struct {
    char     name[24];        
    uint64_t value;           
    uint32_t sec_idx;         
    uint8_t  type;            
    uint8_t  bind;            
    uint16_t flags;           
    uint32_t import_module_offset;  
} KROSymbol;




typedef struct {
    uint64_t offset;          
    uint32_t sym_idx;         
    uint16_t type;            
    int16_t addend;           
} KRORelocation;

#pragma pack(pop)


typedef struct KROWriter KROWriter;


KROWriter* kro_writer_create(void);
void kro_writer_destroy(KROWriter* writer);


uint32_t kro_write_code(KROWriter* writer, const void* data, uint32_t size);
uint32_t kro_write_data(KROWriter* writer, const void* data, uint32_t size);
uint32_t kro_write_rodata(KROWriter* writer, const void* data, uint32_t size);


uint32_t kro_write_code_aligned(KROWriter* writer, const void* data, uint32_t size, uint32_t align);
uint32_t kro_write_data_aligned(KROWriter* writer, const void* data, uint32_t size, uint32_t align);


bool kro_reserve_bss(KROWriter* writer, uint32_t size, uint8_t align_log2);


int kro_add_symbol(KROWriter* writer, const char* name, uint8_t type, uint8_t bind,
                  uint32_t sec_idx, uint64_t value);
int kro_add_undefined_symbol(KROWriter* writer, const char* name);
int kro_add_import_symbol(KROWriter* writer, const char* name, const char* module);
int kro_find_symbol(KROWriter* writer, const char* name);
void kro_update_symbol_value(KROWriter* writer, int sym_idx, uint64_t value);


void kro_add_reloc(KROWriter* writer, uint32_t sec_idx, uint64_t offset,
                  uint32_t sym_idx, uint16_t type, int16_t addend);


bool kro_set_entry_point(KROWriter* writer, uint64_t offset);


uint32_t kro_get_code_offset(KROWriter* writer);
uint32_t kro_get_data_offset(KROWriter* writer);
uint32_t kro_get_rodata_offset(KROWriter* writer);
void kro_set_code_offset(KROWriter* writer, uint32_t offset);


bool kro_write_file(KROWriter* writer, const char* filename);

#endif
