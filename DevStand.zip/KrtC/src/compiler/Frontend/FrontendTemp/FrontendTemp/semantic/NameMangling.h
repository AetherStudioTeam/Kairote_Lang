#ifndef KRT_NAME_MANGLING_H
#define KRT_NAME_MANGLING_H

#include "../parser/Ast.h"

/**
 * 名称粉碎（Name Mangling）机制
 * 
 * 格式：_ZN<length><namespace1><length><namespace2>...<name>E<suffix>
 * 
 * 示例：
 * - System::Math::Max -> _ZN6System4Math3MaxE
 * - System::IO::File::Read -> _ZN6System2IO4File4ReadE
 * - 全局函数 main -> _Z4mainv
 * - 类成员函数 Class::Method -> _ZN5Class6MethodE
 * 
 * 编码规则：
 * - _Z: 名称粉碎标识符
 * - N: 嵌套名称（Nested name）
 * - 数字：后续标识符的长度
 * - E: 名称结束标记
 * - 后缀：参数类型等信息（可选）
 */

/**
 * 名称粉碎结果结构
 */
typedef struct {
    char* mangled_name;      // 粉碎后的名称
    int success;             // 是否成功
    size_t total_length;     // 总长度
} NameManglingResult;

/**
 * 创建名称粉碎器
 * @return 成功返回 1，失败返回 0
 */
int name_mangling_init(void);

/**
 * 销毁名称粉碎器（释放静态资源）
 */
void name_mangling_cleanup(void);

/**
 * 简单的名称粉碎（仅用于类成员）
 * @param class_name 类名
 * @param member_name 成员名
 * @return 粉碎后的名称（需要手动释放）
 */
char* name_mangle_simple(const char* class_name, const char* member_name);

/**
 * 完整的名称粉碎（支持嵌套命名空间）
 * @param namespaces 命名空间数组（NULL 结尾）
 * @param name 最终名称（函数名、类名等）
 * @return 粉碎后的名称（需要手动释放）
 */
char* name_mangle_names(const char** namespaces, const char* name);

/**
 * 从 AST 节点提取命名空间路径并粉碎名称
 * @param namespace_node 命名空间声明节点
 * @param name 要粉碎的名称
 * @return 粉碎后的名称（需要手动释放）
 */
char* name_mangle_from_ast(ASTNode* namespace_node, const char* name);

/**
 * 粉碎函数名（包含参数信息）
 * @param namespaces 命名空间数组（NULL 结尾）
 * @param function_name 函数名
 * @param param_types 参数类型数组
 * @param param_count 参数数量
 * @return 粉碎后的名称（需要手动释放）
 */
char* name_mangle_function(const char** namespaces, 
                           const char* function_name,
                           KrtTokenType* param_types,
                           int param_count);

/**
 * 粉碎类成员名
 * @param namespaces 命名空间数组（NULL 结尾）
 * @param class_name 类名
 * @param member_name 成员名
 * @return 粉碎后的名称（需要手动释放）
 */
char* name_mangle_class_member(const char** namespaces,
                               const char* class_name,
                               const char* member_name);

/**
 * 解析粉碎后的名称（用于错误消息和调试）
 * @param mangled_name 粉碎后的名称
 * @param out_names 输出名称数组
 * @param out_count 输出名称数量
 * @return 成功返回 1，失败返回 0
 */
int name_demangle(const char* mangled_name, char*** out_names, int* out_count);

/**
 * 释放 demangle 结果
 * @param names 名称数组
 * @param count 名称数量
 */
void name_demangle_free(char** names, int count);

#endif // KRT_NAME_MANGLING_H
