#include "NameMangling.h"
#include "../../../../../Core/Utils/KrtCommon.h"
#include "../../../../../Accelerator.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int strcmp(const char *s1, const char *s2);
extern size_t strlen(const char *s);
extern char *strncpy(char *dest, const char *src, size_t n);

/**
 * 计算数字的字符串长度
 */
static int digit_count(int n) {
    if (n == 0) return 1;
    int count = 0;
    while (n > 0) {
        count++;
        n /= 10;
    }
    return count;
}

/**
 * 将整数写入缓冲区，返回写入的字符数
 */
static int write_number(char* buffer, int n) {
    if (n == 0) {
        buffer[0] = '0';
        return 1;
    }
    
    char temp[16];
    int pos = 0;
    while (n > 0) {
        temp[pos++] = '0' + (n % 10);
        n /= 10;
    }
    
    // 反转
    for (int i = 0; i < pos; i++) {
        buffer[i] = temp[pos - 1 - i];
    }
    buffer[pos] = '\0';
    return pos;
}

/**
 * 计算命名空间数组的总长度
 */
static size_t calculate_namespace_length(const char** namespaces) {
    if (!namespaces) return 0;
    
    size_t total = 0;
    for (int i = 0; namespaces[i] != NULL; i++) {
        total += digit_count((int)strlen(namespaces[i]));
        total += strlen(namespaces[i]);
    }
    return total;
}

/**
 * 简单的名称粉碎（仅用于类成员）
 * 格式：<class>__<member>
 */
char* name_mangle_simple(const char* class_name, const char* member_name) {
    if (!class_name || !member_name) {
        return NULL;
    }
    
    size_t class_len = strlen(class_name);
    size_t member_len = strlen(member_name);
    size_t total_len = class_len + member_len + 3; // "__" + "\0"
    
    char* mangled = (char*)KRT_MALLOC(total_len);
    if (!mangled) {
        return NULL;
    }
    
    snprintf(mangled, total_len, "%s__%s", class_name, member_name);
    return mangled;
}

/**
 * 完整的名称粉碎（支持嵌套命名空间）
 * 格式：_ZN<length1><ns1><length2><ns2>...<name>E
 */
char* name_mangle_names(const char** namespaces, const char* name) {
    if (!name) {
        return NULL;
    }
    
    size_t name_len = strlen(name);
    size_t ns_length = calculate_namespace_length(namespaces);
    
    // 计算总长度：_Z + N + namespaces + name_length_digits + name + E + \0
    size_t total_len = 2 + 1 + ns_length + digit_count((int)name_len) + name_len + 1 + 1;
    
    char* mangled = (char*)KRT_MALLOC(total_len);
    if (!mangled) {
        return NULL;
    }
    
    char* ptr = mangled;
    
    // 写入前缀 _Z
    *ptr++ = '_';
    *ptr++ = 'Z';
    
    // 写入 N（表示嵌套名称）
    *ptr++ = 'N';
    
    // 写入命名空间
    if (namespaces) {
        for (int i = 0; namespaces[i] != NULL; i++) {
            size_t len = strlen(namespaces[i]);
            // 写入长度
            ptr += write_number(ptr, (int)len);
            // 写入名称
            memcpy(ptr, namespaces[i], len);
            ptr += len;
        }
    }
    
    // 写入最终名称
    size_t final_len = strlen(name);
    ptr += write_number(ptr, (int)final_len);
    memcpy(ptr, name, final_len);
    ptr += final_len;
    
    // 写入结束标记 E
    *ptr++ = 'E';
    *ptr = '\0';
    
    return mangled;
}

/**
 * 从 AST 节点提取命名空间路径并粉碎名称
 */
char* name_mangle_from_ast(ASTNode* namespace_node, const char* name) {
    if (!name) {
        return NULL;
    }
    
    // 如果没有命名空间节点，直接使用简单名称
    if (!namespace_node) {
        return name_mangle_names(NULL, name);
    }
    
    // 收集命名空间路径
    const char** namespaces = NULL;
    int ns_count = 0;
    int ns_capacity = 8;
    
    namespaces = (const char**)KRT_MALLOC(sizeof(const char*) * (size_t)(ns_capacity + 1));
    if (!namespaces) {
        return NULL;
    }
    
    // 遍历命名空间节点，收集所有命名空间名称
    ASTNode* current = namespace_node;
    while (current && current->type == AST_NAMESPACE_DECLARATION) {
        if (ns_count >= ns_capacity) {
            ns_capacity *= 2;
            namespaces = (const char**)KRT_REALLOC(namespaces, sizeof(const char*) * (size_t)(ns_capacity + 1));
            if (!namespaces) {
                return NULL;
            }
        }
        
        namespaces[ns_count++] = current->data.namespace_decl.name;
        current = current->data.namespace_decl.body;
    }
    
    // NULL 结尾
    if (ns_count > 0) {
        namespaces[ns_count] = NULL;
        char* result = name_mangle_names(namespaces, name);
        KRT_FREE(namespaces);
        return result;
    } else {
        KRT_FREE(namespaces);
        return name_mangle_names(NULL, name);
    }
}

/**
 * 粉碎函数名（包含参数信息）
 * 格式：_ZN<namespaces><name>E<param_count><param_types>
 */
char* name_mangle_function(const char** namespaces, 
                           const char* function_name,
                           KrtTokenType* param_types,
                           int param_count) {
    // 先粉碎基本名称
    char* base_mangled = name_mangle_names(namespaces, function_name);
    if (!base_mangled) {
        return NULL;
    }
    
    // 如果没有参数，直接返回
    if (!param_types || param_count <= 0) {
        // 添加 v 表示 void 参数
        size_t base_len = strlen(base_mangled);
        char* result = (char*)KRT_MALLOC(base_len + 2);
        if (!result) {
            KRT_FREE(base_mangled);
            return NULL;
        }
        memcpy(result, base_mangled, base_len);
        result[base_len] = 'v';
        result[base_len + 1] = '\0';
        KRT_FREE(base_mangled);
        return result;
    }
    
    // 计算参数类型编码的长度
    size_t param_encoding_len = 0;
    for (int i = 0; i < param_count; i++) {
        switch (param_types[i]) {
            case TOKEN_INT8:
            case TOKEN_INT16:
            case TOKEN_INT32:
            case TOKEN_INT64:
            case TOKEN_UINT8:
            case TOKEN_UINT16:
            case TOKEN_UINT32:
            case TOKEN_UINT64:
                param_encoding_len += 1; // 'i'
                break;
            case TOKEN_FLOAT32:
            case TOKEN_FLOAT64:
                param_encoding_len += 1; // 'f'
                break;
            case TOKEN_BOOL:
                param_encoding_len += 1; // 'b'
                break;
            case TOKEN_STRING:
                param_encoding_len += 1; // 's'
                break;
            case TOKEN_VOID:
                param_encoding_len += 1; // 'v'
                break;
            default:
                param_encoding_len += 1; // 'x' (unknown)
                break;
        }
    }
    
    // 分配结果内存
    size_t base_len = strlen(base_mangled);
    size_t total_len = base_len + param_encoding_len + 1;
    char* result = (char*)KRT_MALLOC(total_len);
    if (!result) {
        KRT_FREE(base_mangled);
        return NULL;
    }
    
    // 复制基础名称
    memcpy(result, base_mangled, base_len);
    KRT_FREE(base_mangled);
    
    // 编码参数类型
    char* ptr = result + base_len;
    for (int i = 0; i < param_count; i++) {
        switch (param_types[i]) {
            case TOKEN_INT8:
            case TOKEN_INT16:
            case TOKEN_INT32:
            case TOKEN_INT64:
            case TOKEN_UINT8:
            case TOKEN_UINT16:
            case TOKEN_UINT32:
            case TOKEN_UINT64:
                *ptr++ = 'i';
                break;
            case TOKEN_FLOAT32:
            case TOKEN_FLOAT64:
                *ptr++ = 'f';
                break;
            case TOKEN_BOOL:
                *ptr++ = 'b';
                break;
            case TOKEN_STRING:
                *ptr++ = 's';
                break;
            case TOKEN_VOID:
                *ptr++ = 'v';
                break;
            default:
                *ptr++ = 'x';
                break;
        }
    }
    *ptr = '\0';
    
    return result;
}

/**
 * 粉碎类成员名
 */
char* name_mangle_class_member(const char** namespaces,
                               const char* class_name,
                               const char* member_name) {
    if (!class_name || !member_name) {
        return NULL;
    }
    
    // 构建完整的命名空间路径：namespaces + class_name
    int ns_count = 0;
    if (namespaces) {
        while (namespaces[ns_count] != NULL) {
            ns_count++;
        }
    }
    
    const char** full_path = (const char**)KRT_MALLOC(sizeof(const char*) * (size_t)(ns_count + 2));
    if (!full_path) {
        return NULL;
    }
    
    for (int i = 0; i < ns_count; i++) {
        full_path[i] = namespaces[i];
    }
    full_path[ns_count] = class_name;
    full_path[ns_count + 1] = NULL;
    
    char* result = name_mangle_names(full_path, member_name);
    KRT_FREE(full_path);
    return result;
}

/**
 * 解析粉碎后的名称（用于错误消息和调试）
 */
int name_demangle(const char* mangled_name, char*** out_names, int* out_count) {
    if (!mangled_name || !out_names || !out_count) {
        return 0;
    }
    
    // 检查前缀 _Z
    if (strlen(mangled_name) < 2 || mangled_name[0] != '_' || mangled_name[1] != 'Z') {
        return 0;
    }
    
    const char* ptr = mangled_name + 2;
    *out_count = 0;
    *out_names = NULL;
    
    int capacity = 8;
    *out_names = (char**)KRT_MALLOC(sizeof(char*) * (size_t)capacity);
    if (!*out_names) {
        return 0;
    }
    
    // 跳过 N
    if (*ptr == 'N') {
        ptr++;
    }
    
    // 解析命名空间和名称
    while (*ptr && *ptr != 'E') {
        // 读取长度
        int length = 0;
        while (*ptr >= '0' && *ptr <= '9') {
            length = length * 10 + (*ptr - '0');
            ptr++;
        }
        
        if (length <= 0 || !*ptr) {
            // 解析失败
            name_demangle_free(*out_names, *out_count);
            *out_names = NULL;
            *out_count = 0;
            return 0;
        }
        
        // 扩展数组
        if (*out_count >= capacity) {
            capacity *= 2;
            *out_names = (char**)KRT_REALLOC(*out_names, sizeof(char*) * (size_t)capacity);
            if (!*out_names) {
                return 0;
            }
        }
        
        // 复制名称
        char* name = (char*)KRT_MALLOC((size_t)(length + 1));
        if (!name) {
            name_demangle_free(*out_names, *out_count);
            *out_names = NULL;
            *out_count = 0;
            return 0;
        }
        
        memcpy(name, ptr, (size_t)length);
        name[length] = '\0';
        (*out_names)[(*out_count)++] = name;
        ptr += length;
    }
    
    // 跳过 E
    if (*ptr == 'E') {
        ptr++;
    }
    
    return 1;
}

/**
 * 释放 demangle 结果
 */
void name_demangle_free(char** names, int count) {
    if (!names) return;
    
    for (int i = 0; i < count; i++) {
        if (names[i]) {
            KRT_FREE(names[i]);
        }
    }
    KRT_FREE(names);
}

/**
 * 初始化名称粉碎器
 */
int name_mangling_init(void) {
    return 1;
}

/**
 * 清理名称粉碎器
 */
void name_mangling_cleanup(void) {
    // 目前没有静态资源需要清理
}
